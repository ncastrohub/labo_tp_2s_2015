# -*- coding: utf-8 -*-

from pygobstones import main

main()
