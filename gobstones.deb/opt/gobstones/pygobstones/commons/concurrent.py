import threading
import multiprocessing

Queue = multiprocessing.Queue
Process = multiprocessing.Process
Thread = threading.Thread