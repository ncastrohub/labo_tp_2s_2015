#!/usr/bin/python
# -*- coding: utf-8 -*-

import pygobstoneslang
from pygobstones.pygobstones import main

main()