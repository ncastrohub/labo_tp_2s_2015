Para ejecutar el Gobsman debe:
  - abrir la herramienta de PyGobstones
  - cargar el Gobsman.gbs en la ventana de código (la Biblioteca.gbs se cargará automáticamente)
  - cargar como tablero inicial el tableroInicialGobsman.gbb 
  - apretar RUN

Para jugar al Gobsman Interactivo debe:
  - abrir la herramienta de PyGobstones
  - cargar el interactiveGobsman.gbs en la ventana de código (la Biblioteca.gbs se cargará automáticamente)
  - cargar como tablero inicial el tableroInicialGobsman.gbb 
  - apretar RUN

  # Teclas para jugar __

	* W -> Mover al norte
	* S -> Mover al sur
	* A -> Mover al oeste
	* D -> Mover al este
	* Cualquier otra tecla -> sin comportamiento
