Para jugar al Zilfost debe:
  - abrir la herramienta de PyGobstones
  - cargar el Zilfost.gbs en la ventana de c�digo (la Biblioteca.gbs se cargar� autom�ticamente)
  - cargar como tablero inicial el tableroInicialZILFOST.gbb 
     (o uno similar de su dise�o, que respete las convenciones de codificaci�n)
  - en el tablero anterior puede variar el n�mero representado en la zona de semilla para obtener diferentes secuencias de piezas
  - elegir si quiere un progama interactivo o uno simple, comentando/descomentando las partes adecuadas del programa
  - ejecutar
  - puede alternar entre la vestimenta de zilfost-romano o la vista est�ndar (con bolitas)
     (La vestimenta zilfost-romano no identifica las piezas por su n�mero)
  - en la versi�n interactiva, se utilizan las siguientes teclas:
     - I, flecha hacia arriba       -> agrega una nueva pieza a la zona de juego
                                       (si hay lugar)
     - d�gitos num�ricos            -> ingresan un c�digo de selecci�n en la zona de selecci�n
                                       (al completar un c�digo las piezas bajan)
     - B, ESCAPE, DELETE, BACKSPACE -> borra la zona de selecci�n
     - J, flecha hacia la izquierda -> mueve a la izquierda la pieza seleccionada 
                                       (la indicada en la zona de selecci�n)
     - L, flecha hacia la derecha   -> mueve a la derecha la pieza seleccionada 
                                       (la indicada en la zona de selecci�n)
     - K, flecha hacia abajo        -> mueve hacia abajo la pieza seleccionada 
                                       (la indicada en la zona de selecci�n)
     - D, ENTER                     -> rota la pieza seleccionada en sentido horario
     - A, SPACE                     -> rota la pieza seleccionada en sentido antihorario
     - CTRL-D                       -> termina la ejecuci�n interactiva
     - cualquier otra tecla         -> baja las piezas
    